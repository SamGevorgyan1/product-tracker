package producttracker.storageexception

import producttracker.exceptions.ResourceAlreadyExistsException

class StorageResourceAlreadyExistsException extends ResourceAlreadyExistsException{
     StorageResourceAlreadyExistsException(String message) {
        super(message)
    }

     StorageResourceAlreadyExistsException(String message, Throwable cause) {
        super(message, cause)
    }
}
