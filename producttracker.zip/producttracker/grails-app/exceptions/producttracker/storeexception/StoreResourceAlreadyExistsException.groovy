package producttracker.storeexception

import producttracker.exceptions.ResourceAlreadyExistsException

class StoreResourceAlreadyExistsException extends ResourceAlreadyExistsException {
    StoreResourceAlreadyExistsException(String message) {
        super(message)
    }
    StoreResourceAlreadyExistsException(String message, Throwable cause) {
        super(message, cause)
    }
}