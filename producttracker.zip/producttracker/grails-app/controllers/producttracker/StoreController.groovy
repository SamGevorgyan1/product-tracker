package producttracker


class StoreController {

    StoreService storeService


    def create() {
        [storeInstance: new Store()]
    }

    def show(String id) {
        def store = Store.findById(UUID.fromString(id))
        if (!store) {
            flash.message = "Store not found with id ${id}"
            redirect(action: "index")
            return
        }
        [store: store]
    }

    def save(Store store) {
        try {
            store.address = params.address
            storeService.create(store)
            redirect(action: "index")
        } catch (e) {
            flash.message = "Error saving store: ${e.message}"
            //render(view: "create", model: [storeInstance: store, addressInstance: address])
        }
    }

    def sellProduct() {
        UUID storeId = UUID.fromString(params.storeId)
        String productCode = params.productCode
        int quantity = params.int('quantity')
        try {
           storeService.sellProduct(storeId, productCode, quantity)
            flash.message = "Product sold successfully"
        } catch (e) {
            flash.error = e.message
        }
        redirect(action: 'show', params: [id: storeId])
    }

    def returnProductToStorage() {
        UUID storeId = UUID.fromString(params.storeId)
        String productCode = params.productCode
        int quantity = params.int('quantity')
        UUID storageUUID = UUID.fromString(params.storageId)
        try {
            Store store = storeService.returnProductToStorage(storeId, storageUUID, productCode, quantity)
            flash.message = "Product returned to storage successfully. Store: ${store.name}"
        } catch (Exception e) {
            flash.message = e.message
        }
        redirect(action: 'show', id: storeId)
    }


    def edit(Long id) {
        def storeInstance = Store.get(id)
        [storeInstance: storeInstance]
    }

    def update(Store storeInstance) {
        if (storeInstance.save(flush: true)) {
            redirect(action: "index")
        } else {
            render(view: "edit", model: [storeInstance: storeInstance])
        }
    }

    def delete(String id) {
        UUID storeId = UUID.fromString(id)
        try {
            storeService.delete(storeId)
            flash.message = "Store deleted successfully"
        } catch (e) {
            flash.erorr = e.getMessage()
        }
        redirect(action: "index")
    }
}
