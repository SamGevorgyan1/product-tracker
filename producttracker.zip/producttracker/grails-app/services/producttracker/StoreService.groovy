package producttracker

import grails.gorm.transactions.Transactional
import producttracker.productexception.ProductNotFoundException
import producttracker.storageexception.StorageNotFoundException
import producttracker.storeexception.StoreApiException
import producttracker.storeexception.StoreBadRequestException
import producttracker.storeexception.StoreNotFoundException
import java.time.LocalDate


@Transactional
class StoreService implements MessageHelperTrait {

    /**
     * Deletes a store by its ID.
     *
     * @param id UUID of the store to be deleted.
     * @throws StoreApiException if an error occurs during deletion.
     */
    void delete(UUID id) {
        def store = findById(id)
        try {
            store.delete(flush: true)
        } catch (e) {
            throw new StoreApiException(getMessage('store.delete.error'), e)
        }
    }

    /**
     * Finds a store by its ID.
     *
     * @param id UUID of the store to find.
     * @return The store with the specified ID.
     * @throws StoreBadRequestException if the provided ID is null.
     * @throws StoreNotFoundException if the store with the specified ID is not found.
     */
    Store findById(UUID id) {
        if (id == null) {
            throw new StoreBadRequestException(getMessage('store.find.id.null'))
        }
        Store store = Store.findById(id)
        if (!store) {
            throw new StoreNotFoundException(getMessage('store.not.found', [id] as Object[]))
        }
        return store
    }

    /**
     * Creates a new store.
     *
     * @param store The store object to be created.
     * @throws StoreBadRequestException if the store ID is not null or the store name is null.
     */
    Store create(Store store) {
        if (store.id != null) {
            throw new StoreBadRequestException(getMessage('store.id.must.be.null'))
        }
        if (store.name == null) {
            throw new StoreBadRequestException(getMessage('store.name.null'))
        }
        store.save(flush: true)
    }

    /**
     * Sells a product from the store.
     *
     * @param storeId UUID of the store where the product will be sold.
     * @param productCode Barcode of the product to be sold.
     * @param quantity Quantity of the product to be sold.
     * @throws StoreBadRequestException if product code or quantity is null.
     * @throws StoreNotFoundException if the store is not found.
     * @throws ProductNotFoundException if the product is not found.
     * @throws StoreBadRequestException if there is insufficient quantity of the product in the store.
     */
    void sellProduct(UUID storeId, String productCode, Integer quantity) {
        if (productCode == null) {
            throw new StoreBadRequestException(getMessage('product.code.null'))
        }
        if (quantity == null) {
            throw new StoreBadRequestException(getMessage('product.quantity.null'))
        }

        Store store = findById(storeId)
        if (!store) {
            throw new StoreNotFoundException(getMessage('store.not.found'))
        }
        Product product = Product.findByBarcode(productCode)
        if (!product) {
            throw new ProductNotFoundException(getMessage('product.not.found'))
        }
        StoreProduct storeProduct = StoreProduct.findByStoreAndProduct(store, product)
        if (!storeProduct || storeProduct.quantity < quantity) {
            throw new StoreBadRequestException(getMessage('insufficient.product.quantity'))
        }
        storeProduct.quantity -= quantity
        if (storeProduct.quantity == 0) {
            storeProduct.delete(flush: true)
        } else {
            storeProduct.save(flush: true)
        }
        store.save(flush: true)
    }

    /**
     * Returns a product to storage from the store.
     *
     * @param storeId UUID of the store where the product will be returned from.
     * @param storageId UUID of the storage where the product will be returned to.
     * @param productCode Barcode of the product to be returned.
     * @param quantity Quantity of the product to be returned.
     * @return The updated store after returning the product.
     * @throws StorageNotFoundException if the storage is not found.
     * @throws StoreBadRequestException if there is insufficient quantity of the product in the store.
     */
    Store returnProductToStorage(UUID storeId, UUID storageId, String productCode, int quantity) {
        Store store = findById(storeId)
        Storage storage = Storage.findById(storageId)
        Product product = Product.findByBarcode(productCode)

        if (!storage) {
            throw new StorageNotFoundException(getMessage('storage.not.found'))
        }

        StoreProduct storeProduct = StoreProduct.findByStoreAndProduct(store, product)
        if (!storeProduct || storeProduct.quantity < quantity) {
            throw new StoreBadRequestException(getMessage('insufficient.product.quantity'))
        }

        StorageProduct storageProduct = StorageProduct.findByStorageAndProduct(storage, product)
        if (storageProduct) {
            storageProduct.quantity += quantity
        } else {
            storageProduct = new StorageProduct(product: product, storage: storage, quantity: quantity).save(flush: true)
        }
        storage.addToStorageProducts(storageProduct)
        storeProduct.quantity -= quantity
        if (storeProduct.quantity == 0) {
            storeProduct.delete(flush: true)
        }

        store.save(flush: true)
        storage.save(flush: true)
        return store
    }

    /**
     * Handles expired products by returning them to storage.
     */
    void handleExpiredProducts() {
        Store.findAll().each { store ->
            store.storeProducts.each { storeProduct ->
                if (storeProduct.product.deadline != null && storeProduct.product.deadline.isBefore(LocalDate.now())) {
                    returnProductToStorage(store.id, storeProduct.product.id, storeProduct.product.barcode, storeProduct.quantity)
                }
            }
        }
    }

    /**
     * Lists all stores.
     *
     * @return A list of all stores.
     */
    List<Store> list() {
        return Store.list()
    }
}
